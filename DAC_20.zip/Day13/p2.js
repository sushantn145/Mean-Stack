let callJSON = () => {
    console.log('JSON');
    //step-1
    let xhr = new XMLHttpRequest();

    //step-2
    url = "https://fakerestapi.azurewebsites.net/api/Books";
    xhr.open("GET", url);
    //handshaking communication between client and server
    xhr.onload = () => {
        console.log(xhr.readyState);
        let refjsontext = xhr.responseText;
        console.log(refjsontext);
        let refjson = JSON.parse(refjsontext);
        console.log(refjson);
        domlogicJSON(refjson);
    }
    //step-3
    xhr.send();
}

function domlogicJSON(refjson) {
    let book = refjson.Title;
    //let newElement = document.querySelector('#child2');
    //for (i = 0; i < refjson.length; i++) {
    //let desc = newElement.children[0].innerHTML = book.Title + " " + book.PageCount;
    //console.log(desc);
    // }
}
let callXML = () => {
    console.log('XML');
}