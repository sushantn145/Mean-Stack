let callAJAX = () => {
    console.log("hello");
    //step 1
    let xhr = new XMLHttpRequest();


    let parent = document.querySelector('#parentblock');
    let cityname = parent.children[0].children[0].children[2].value;
    console.log(cityname);
    //step-2
    let url = "https://api.openweathermap.org/data/2.5/weather?appid=b11ccaf17696425de78feb2550ceef62&units=metric&q=" + cityname;
    xhr.open("GET", url);
    //step-3
    xhr.onload = () => {
        let refjson = JSON.parse(xhr.responseText);
        console.log(refjson);
        Domlogic(refjson);
    }

    //step-4
    xhr.send();
    parent.children[0].children[0].children[2].value = "";
}

function Domlogic(refjson) {
    console.log(refjson);
    console.log('parent');
    const name1 = refjson.name;
    console.log(name1);
    const temp1 = refjson.main.temp;
    console.log(temp1);
    const humidity1 = refjson.main.humidity;
    console.log(humidity1);
    var d = new Date();
    let parent = document.querySelector('#parentblock');
    parent.children[1].style.display = "flex";
    //let mainblock = parent.children[0];
    parent.children[1].children[0].children[0].children[0].children[0].innerHTML = name1;
    parent.children[1].children[0].children[0].children[2].innerHTML = d;
    parent.children[1].children[0].children[0].children[4].children[0].innerHTML = temp1;
    parent.children[1].children[0].children[0].children[7].children[0].innerHTML = humidity1;
    //parent.insertBefore(mainblock, parent.firstchild);



}

