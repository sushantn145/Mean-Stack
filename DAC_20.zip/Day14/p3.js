callAjaxUsingJQuery = () => {
    console.log('hello');
    let cityname = "mumbai";
    url = "https://api.openweathermap.org/data/2.5/weather?appid=b11ccaf17696425de78feb2550ceef62&units=metric&q=" + cityname;

    $.ajax(url).done((data) => {
        console.log(data);
        domlogichere(data);
    });
};

domlogichere = (data) => {
    let newElement = $("#parent:nth-child(1)").clone(true);
    newElement.html(data.name + " " + data.main.temp);
    newElement.insertBefore($("#parent :nth-child(1)"));
}

domlogichere1 = (data) => {
    //let parent = document.querySelector('#parent');
    //Using Jquery
    //let parent = $('#parent');

    //let newElement = parent.children[0].cloneNode(true);
    //Using JQuery
    let newElement = $("#parent div:nth-child(1)").clone(true);
    //parent.children()
    //$('#parent').children().first().next()
    //$('#parent div:nth-child(2)')
    //$('#parent :nth-child(2)')
    //$('#parent :first.child')     //Not giving proper output
    //newElement.innerHTML = data.name + " " + data.main.temp;
    //using JQuery
    newElement.html(data.name + " " + data.main.temp);

    //parent.appendChild(newElement);
    // using Jquery
    parent.insertBefore($(newElement, "#parent div:nth-child(1)"));
}   