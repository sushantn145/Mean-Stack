callAjaxUsingJQuery = () => {
    let url = "https://api.openweathermap.org/data/2.5/weather?appid=b11ccaf17696425de78feb2550ceef62&units=metric&q=" + "Pune";
    $.ajax(url).done((data) => {
        console.log(data);
        myDomoperation(data);
    });
};

myDomoperation = (data) => {
    let parent = document.querySelector('#parent');

    newElement = parent.children[1].cloneNode(true);
    newElement.innerHTML = data.name + "" + "Temp" + data.main.temp_max;
    parent.appendChild(newElement);

}