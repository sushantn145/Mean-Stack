

let callAjax = function () {
    //step-1
    let xhr = new XMLHttpRequest();
    console.log(xhr);
    //step-2
    let url = "https://reqres.in/api/users?page=2";
    xhr.open("GET", url);

    //handshaking
    xhr.onload = () => {
        const refJson = JSON.parse(xhr.responseText);
        console.log(refJson);
        Domlogic(refJson);
    }
    //step-4
    xhr.send();
}

let Domlogic = function (refJson) {
    console.log(refJson);

    let parent1 = document.querySelector('#parent');

    for (i = 0; i < refJson.data.lenght; i++) {
        const item = refJson.data[i];

        let newElement = parent1.children[0].cloneNode(true);

        newElement.innerHTML = item.first_name + " " + item.last_name;
        parent.insertBefore(newElement, parent1.firstChild);
    }
};