const Promise = require('bluebird');
const mysql = require('mysql');

Promise.promisifyAll(require('mysql/lib/Connection').prototype);
Promise.promisifyAll(require('mysql/lib/Pool').prototype);


const DB_Login = {
    host: "localhost",
    user: "root",
    password: "Sushantn145@",
    database: "test1",
};

const readdata = async () => {
    const Connection = mysql.createConnection(DB_Login);
    const sql = "select ??,?? from ?? where sname=?";
    const result = await Connection.queryAsync(sql, ["id", "sname", "student", "Sushant Nikale"]);

    console.log(result);

    await Connection.end();
    return result;

};

readdata();