const Promise = require('bluebird');
const mysql = require('mysql');

//promisification for mysql query::bcoz of this no need to use callback
Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readdata = async () => {
    console.log("HELO");
    const connection = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "Sushantn145@",
        database: "test1"
    });
    await connection.connectAsync();
    console.log("connection succesful");

    //select query
    const sql = "SELECT *FROM STUDENT";
    const result = await connection.queryAsync(sql);

    console.log(result);
    connection.end();

    return result;
};

readdata();