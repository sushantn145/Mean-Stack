const Promise = require('bluebird');
const mysql = require('mysql');


Promise.promisifyAll(require('mysql/lib/Connection').prototype);
Promise.promisifyAll(require('mysql/lib/Pool').prototype);

/*const DB_Login = {
    host: "127.0.0.1",
    user: "root",
    password: "Sushantn145@",
    database: "test1",
};*/
const readdata = async () => {
    try {
        const Connection = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "Sushantn145@",
            database: "test1"
        });

        const sql = "update student set sname='Sushant Nikale' where id=5";
        const result = await Connection.queryAsync(sql);
        console.log(result);

        await Connection.end();
        return result;
    } catch (err) {
        console.log("Error shown below")
    }

};

readdata();