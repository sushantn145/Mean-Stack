const Promise = require('bluebird');
const mysql = require('mysql');


Promise.promisifyAll(require('mysql/lib/Connection').prototype);
Promise.promisifyAll(require('mysql/lib/pool').prototype);

const DB_LOGIN = {
    host: "127.0.0.1",
    user: "root",
    password: "Sushantn145@",
    database: "test1",
};

let readdata = async () => {
    console.log("Hello");
    const Connection = mysql.createConnection(DB_LOGIN);

    const sql = "select * from student where id=5";
    const result = await Connection.queryAsync(sql);

    console.log(result);

    await Connection.end();
    return result;

};
let deletedata = async () => {
    const Connection = mysql.createConnection(DB_LOGIN);

    const sql = "delete from student where id=5";
    const result = await Connection.queryAsync(sql);

    await Connection.end();
    return result;
}

readdata();
deletedata();

