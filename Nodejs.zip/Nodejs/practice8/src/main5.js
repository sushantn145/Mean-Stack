const Promise = require('bluebird');
const mysql = require('mysql');


Promise.promisifyAll(require('mysql/lib/Connection').prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


let readdata = async (data) => {
    console.log("Hello ");

    const Connection = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "Sushantn145@",
        database: "test1",
    });

    await Connection.connectAsync();
    console.log("connection Successful");
    const sql = "INSERT INTO STUDENT(id,sname,address,mobno) values(?,?,?,?)";
    const result = await Connection.queryAsync(sql, data);
    console.log(result);
    Connection.end();
    return result;
};

const data = ["Parag Gawade", "Pune", "857496"];
readdata(data)
    .then((data) => { console.log("Data Sent Successfull") })
    .catch((err) => { console.log("Error in Data") });