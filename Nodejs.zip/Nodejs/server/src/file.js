const http = require('http');
const fs = require('fs');

let readfile = () => {

    //Blocking in nature
    const output = fs.readFileSync('package.json', { encoding: "utf-8" });
    console.log(output);



}
let readfileAsyncwithoutsequential = () => {
    //Non Blcoking::Takes callback::Asynchronous in nature
    fs.readFile('package.json', { encoding: "utf-8" }, (err, data) => {
        console.log(data);
    });
    fs.readFile('G:/Sushant/AWP/nodeJS/Nodejs/server/src/text.txt', { encoding: "utf-8" }, (err, data) => {
        console.log(data);
    });
}

let readfileAsyncsequential = () => {
    //Non Blcoking::Takes callback::Asynchronous in nature
    fs.readFile('package.json', { encoding: "utf-8" }, (err, data) => {
        console.log(data);

        fs.readFile('G:/Sushant/AWP/nodeJS/Nodejs/server/src/text.txt', { encoding: "utf-8" }, (err, data) => {
            console.log(data);
        });
    });

}
//readfile();
//readfileAsync();
//readfileAsyncwithoutsequential();
readfileAsyncsequential();