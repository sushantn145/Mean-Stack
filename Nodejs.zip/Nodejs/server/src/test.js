const http = require('http');
const mod = require('./mod');


http.createServer((req, res) => {
    let input = mod.data;

    let output = "Hello World!!!!!";
    let str = JSON.stringify(input);

    res.end(str);
}).listen(3000);