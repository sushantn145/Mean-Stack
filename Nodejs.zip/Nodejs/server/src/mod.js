let data = {
    id: 1,
    name: "sushant",
};

module.exports = { data };