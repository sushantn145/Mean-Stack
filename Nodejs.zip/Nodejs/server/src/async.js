// let hello = async () => {
//     console.log("Hello");
//     return 4 + 5;
// };
//console.log(hello());
// let hello = async () => {
//     return "Welcome";
// };

// const output = hello();
// console.log(output);

let hello = async () => {
    return "Welcome";
};
const mpromise = hello();
//two state::
//if state Success
mpromise.then((data) => {
    console.log(data);
});
mpromise.catch((err) => {
    console.log(err);
});

