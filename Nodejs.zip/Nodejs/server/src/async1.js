// let hello = async () => {
//     return "Welcome";
// };
// const mpromise = hello();
// //two state::
// //if state Success
// mpromise.then((data) => {
//     console.log(data);
// }).catch((err) => {
//     console.log(err);
// });

let hello = async () => {
    return "Welcome";
};

hello()
    .then((data) => {
        console.log(data);
    }).catch((err) => {
        console.log(err);
    });
