const fs = require('fs');
const Promise = require('bluebird');

Promise.promisifyAll(fs);

let promisedemo = async () => {
    // fs.readFile('package.json', { encoding: "utf-8" }, (err, data) = {
    // });

    const data = await fs.readFileAsync('package.json', { encoding: "utf-8" });
    console.log(data);

};

promisedemo();

let promisedemowrite = async () => {
    const data = "Hello world";

    fs.writeFile('src\text.txt', (err, data) => {
        if (err) throw err;
        console.log(data);
    });
}
promisedemowrite();
