const Promise = require("bluebird");
const mysql = require("mysql");
//const babel = require('babel');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_Login = require("./dbconfig");

let adduser = async (data) => {
    const connection = mysql.createConnection(DB_Login.DB_Login);

    await connection.connectAsync();
    console.log("connection Successful");

    const sql = "insert into student (id,sname,address,mobno) values(?,?,?,?)";
    const result = await connection.queryAsync(sql, [data.id, data.sname, data.address, data.mobno]);
    console.log(result);

    await connection.endAsync();
};

module.exports = { adduser }


