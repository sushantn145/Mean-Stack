// const express = require("express");
// //const bodyParser=require("body-parser");
// const cors = require("cors");

// const app = express();

// app.use(express.json());//this will help to read the data coming in body :: TEXT to JSON
// app.use(cors());//unblocking cors policy available to all browser


// const adduser = require("./dbadd");
// //http://localhost:3000/adduser?id=123&sname=sushant&address=Loni&mobno=88777
// app.get("/adduser", async (req, res) => {
//     try {

//         const data = req.query;

//         await adduser.adduser(data);
//         // const json = {
//         //     id: 1,
//         //     name: "Sushant",
//         // }
//         // res.json(json);
//         //res.send(CDAC);
//         //console.log(res)
//     } catch (err) {
//         console.log("Fail");
//     }
// });

// app.post("/adduser", async (req, res) => {
//     try {

//         const data = req.body;// before doing this write above this line app.use(express.json());
//         console.log(req.body);
//         await adduser.adduser(data);
//         res.joson({ message: "Success" });
//     } catch (err) {
//         res.json({ message: "Fail" });
//     }

// });
// //
// // app.post("/addInfo", async (req, res) => {
// //     try {
// //         const input = req.body;
// //         await dbFun.addInfo(input);
// //         res.json({ message: "success" });
// //     } catch (err) {
// //         res.sendStatus(500);
// //     }
// // });

// //http:localhost:3000/search?username=Sushant&email=sush.nik145@gmail.com&mobno=7920176551;
// app.get("/search", (req, res) => {

//     const input = req.query;

//     res.json(input);

// })
// app.listen(4000);
///////////////////////////////////////////////////////////////////////////////

const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

const dbFun = require("./dbadd");

// app.get('/', (req, res) => {
//     res.send("Hello World");
// });

// app.get('/addInfo', async (req, res) => {
//     try {
//         const input = req.query;
//         await dbFun.addInfo(input);
//         res.json({ message: "success" });
//     } catch (err) {
//         res.sendStatus(500);
//     }
// });

app.post("/adduser", async (req, res) => {
    try {
        const data = req.body;
        await dbFun.adduser(data);
        res.json({ message: "success" });
    } catch (err) {
        res.sendStatus(500);
    }
});

app.listen(3000);
