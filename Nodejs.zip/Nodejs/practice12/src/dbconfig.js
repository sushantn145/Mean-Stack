const DB_Login = {
    host: "localhost",
    user: "root",
    password: "Sushantn145@",
    database: "test1",
};

module.exports = { DB_Login }