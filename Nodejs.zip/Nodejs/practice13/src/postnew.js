const express = require('express');
const cors = require('cors');

const app = express();
app.use(express.json()); //parsing the request body of POST
app.use(cors()); // ajax request

const dbadd = require("./dbadd");
app.get('/', (req, res) => {
    res.json({ title: "Sushany" });
})


// app.post('/adduser', (req, res) => {

//     res.json({ title: "sushant" });
// });
app.post("/adduser", async (req, res) => {
    try {
        const input = req.body;
        console.log(input);
        await dbadd.adduser(input);

        res.json({ message: "success" });
    } catch (err) {
        res.json({ message: "fail", err });
    }
});


app.listen(3000);

