const express = require('express');
const app = express();


app.get('/', (req, res) => {
    res.send("Hello World");
});
//to get a feed
app.get('/feed', (req, res) => {
    res.json({
        id: 1,
        name: "Sushant",
        Address: "Loni Kalbhor,Pune"
    });
});
//create feed in server
app.post('/feed', (req, res) => {
    res.json({
        title: "I am post Request"
    })
});
//to update a feed
app.put("/feed", (req, res) => {
    res.json({ title: "Hello I M PUT" });
});
//to delete a feed(data)
app.delete('/feed', (req, res) => {
    res.json({ title: "I M DELETE " });
});
app.listen(3000);