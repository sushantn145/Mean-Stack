const express = require('express');
const app = express();

//http://localhost:3000/search?q=node.js
app.get('/search', (req, res) => {
    const input = req.query;
    res.json({ title: "STudying request" })
})
app.listen(3000);