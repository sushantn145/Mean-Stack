const express = require('express');
const multer = require('multer');//used for to parse multipath data 
const app = express();

app.use(express.urlencoded({ extended: true }));//parsing url encode data
app.use(express.json())//parsing row ::json data
var upload = multer();//for text



app.get('/', (req, res) => {
    res.send("hello");
});

app.post('/adduser', upload.none(), (req, res) => {
    const inputquery = req.query;
    const input = req.body;//parsing is required

    res.json({
        title: "Sushsan"
    });
})
app.listen(3000);