const express = require('express');
const app = express();


app.get('/', (req, res) => {
    res.send("Hello World");
});
//to get a feed
app.get('/text', (req, res) => {
    res.send("Serving text Response")
});
app.get('/json', (req, res) => {
    res.send({ Name: "SUshant", Surname: "Nikalje" })
});

//Serving an Image
app.get('/img', (req, res) => {
    //res.send(__dirname);
    const filepath = __dirname + "/bg1.jpg";
    res.sendFile(filepath);
});

//PDF File
app.get('/pdf', (req, res) => {
    //res.send(__dirname);
    const filepath = __dirname + "/pdffile.pdf";
    res.sendFile(filepath);
});






// //create feed in server
// app.post('/feed', (req, res) => {
//     res.json({
//         title: "I am post Request"
//     })
// });
// //to update a feed
// app.put("/feed", (req, res) => {
//     res.json({ title: "Hello I M PUT" });
// });
// //to delete a feed(data)
// app.delete('/feed', (req, res) => {
//     res.json({ title: "I M DELETE " });
// });
app.listen(3000);