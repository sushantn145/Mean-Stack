

console.log('Hello World');

console.log("Hello nodeJS", "Welcome TO CDAC");

console.log(1, 'One');
console.log(2, "Two");