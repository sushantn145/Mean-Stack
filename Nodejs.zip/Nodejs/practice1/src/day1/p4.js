
class Main {
    static main() {
        console.log('Hello world like java')
    }
}

Main.main();