//practice all valiatble
let str = "Hello"

console.log(str);