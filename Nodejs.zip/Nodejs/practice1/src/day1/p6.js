/*
#Data Member
#Constructor
#Member Function
*/

class Person {

    //Special Function::Constructor
    constructor() {
        console.log("I AM Constructor");
    }
    //Normal fuction:: Member Function
    getPersonName() {
        return "Sushant";
    }

    getPersonAddress() {
        return "Mumbai";
    }

    getPersonDetails() {
        const name = this.getPersonName();
        const address = this.getPersonAddress();
        return name + " " + address;
    }
    //NormalFUntcion:static Member Function
    static main() {
        let p = new Person();
        const details = p.getPersonDetails(); "\n"
        console.log(details);
    }
}

Person.main();