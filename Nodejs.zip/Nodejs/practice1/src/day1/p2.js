
setInterval(() => {
    console.log('I m cool interval', new Date)
}, 2500);