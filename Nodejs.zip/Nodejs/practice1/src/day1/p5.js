
class Calculator {

    add(n1, n2) {
        return n1 + n2;
    }
    sub(n1, n2) {
        return n1 - n2
    }
    mul(n1, n2) {
        return n1 * n2;
    }
    div(n1, n2) {
        return (n1 / n2);
    }
    add(n1, n2, n3) {
        return n1 + n2 + n3;
    }

    //Execution point
    static main() {
        let obj = new Calculator();
        let addition = obj.add(2, 3);
        console.log(addition);
        let subtraction = obj.sub(5, 3);
        console.log(subtraction);
        let multiplication = obj.mul(2, 3);
        console.log(multiplication);
        let division = obj.div(8, 2);
        console.log(division)
        let add1 = obj.add(2, 3, 5);
        console.log(add1);
    }
}
Calculator.main();
/*let obj = new Calculator();
let output = obj.add(1, 2);
console.log(output);

let subtraction = obj.subtract(5, 2);
console.log(subtraction);*/