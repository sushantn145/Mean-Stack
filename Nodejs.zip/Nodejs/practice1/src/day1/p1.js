//Declaation function
function helloworld() {
    console.log('I am named FUnction');

}

helloworld();
