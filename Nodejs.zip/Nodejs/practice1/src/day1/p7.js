

let json = {
    Name: 'Sushant',
    Age: '28',
    Education: "CDAC"

}
console.log(json.Name, json.Age, json.Education);