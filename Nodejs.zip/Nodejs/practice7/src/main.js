const fs = require('fs');
const Promise = require('bluebird');
const { fileURLToPath } = require('url');

Promise.promisifyAll(fs);



let readdemo = () => {
    const filepath = "G:/Sushant/AWP/links.txt";

    fs.readFileSync(filepath, { encoding: "utf-8" })
        .then((data) => {
            console.log(data);
        }).catch((err) => {
            console.log(err);
        })
};

readdemo();

