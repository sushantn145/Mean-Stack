const dbread = require('./read');
const dbadd = require("./add");
const dbremove = require("./remove");

//dbread.readdata();
//dbread.readdata(5, "Pune");
/*
dbadd.add({
    id: "1",
    sname: "Umesh Gite",
    address: "Bhavani Peth",
)*/
 dbadd.add(
    "student",
    1,
   "Umesh Gite",
   "Bhavani Peth",
   "1567891" );

//dbadd.add(6, "Prahant Gorde", "Hadpsar", "5684994");

// dbremove.remove({ address: "Bhavani Peth" });
//bremove.remove("2");