const Promise = require('bluebird');
const mysql = require('mysql');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


const DB_Login = require('./dbconfig');
//Read by query
let readdata = async () => {
    console.log("Hello Welcome");
    const connection = mysql.createConnection(DB_Login.DB_config);

    await connection.connectAsync();
    console.log("connection successful");

    const sql = "select * from student";
    const result = await connection.queryAsync(sql);
    console.log(result);

    connection.end();

};

//Read By parameter
// let readdata = async () => {
//     const connection = mysql.createConnection(DB_Login.DB_config);

//     await connection.connectAsync();
//     console.log("connection Successful");

//     const sql = "select * from student where id=? and address=?";
//     const result = await connection.queryAsync(sql, [5, "Pune"]);
//     console.log(result);


//     connection.end;

// };

//Read by Parameter


// let readdata = async (id, address) => {
//     const connection = mysql.createConnection(DB_Login.DB_config);

//     await connection.connectAsync();
//     console.log("connection Successful");

//     const sql = "select * from student where id=? and address=?";
//     const result = await connection.queryAsync(sql, [id, address]);
//     console.log(result);

//     connection.end();

// };

//Read by object

// let readdata = async (data) => {
//     const connection = mysql.createConnection(DB_Login.DB_config);

//     await connection.connectAsync();
//     console.log("connection Successful");

//     const sql = "select * from student where id=? and address=?";
//     const result = await connection.queryAsync(sql, [data.id, data.address]);
//     console.log(result);

//     connection.end();

// }
module.exports = { readdata }