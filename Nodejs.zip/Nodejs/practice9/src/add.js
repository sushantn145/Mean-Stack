const Promise = require('bluebird');
const mysql = require('mysql');

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_Login = require('./dbconfig');

//Add by Object

// let add = async (data) => {
//     const connection = mysql.createConnection(DB_Login.DB_config);

//     await connection.connectAsync();
//     console.log("connection successful");

//     const sql = "insert into student (id,sname,address,mobno) value (?,?,?,?)";
//     const result = await connection.queryAsync(sql, [data.id, data.sname, data.address, data.mobno]);

//     console.log(result);
//     connection.end()

//     return result;

// };

/*
//Add by Parameter with ASYNC
let add = async (id, sname, address, mobno) => {
    const connection = mysql.createConnection(DB_Login.DB_config);

    await connection.connectasync();
    console.log("connection Successful");

    const sql = "insert into student (id,sname,mobno,address) value(?,?,?,?)";
    const result = await connection.queryasync(sql, [id, sname, mobno, address]);
    console.log(result);

    connection.end();
}
*/

//Add by Parameter 
let add = async (student, id, sname, address, mobno) => {
    const connection = mysql.createConnection(DB_Login.DB_config);

    await connection.connect();
    console.log("connection Successful");

    const sql = "insert into ?? (id,sname,mobno,address) value(?,?,?,?)";
    const result = await connection.query(sql, [student, id, sname, mobno, address]);
    console.log(result);

    connection.end();

}
module.exports = { add }