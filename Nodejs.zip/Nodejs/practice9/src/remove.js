const Promise = require('bluebird');
const mysql = require('mysql');

Promise.promisifyAll(require('mysql/lib/Connection').prototype);
Promise.promisifyAll(require('mysql/lib/Pool').prototype);

const DB_Login = require("./dbconfig");
/*
let remove = async (data) => {
    const connection = mysql.createConnection(DB_Login.DB_config);

    await connection.connectAsync();
    console.log("connection successful");

    const sql = "delete from student where address=?";
    const result = await connection.queryAsync(sql, [data.address]);
    console.log(result);

    connection.end();

    return result;
};
*/
//remove by parameter
let remove = async (id) => {
    const connection = mysql.createConnection(DB_Login.DB_config);

    await connection.connect();
    console.log("COnnecton successful");

    const sql = "delete from student where id=?";
    const result = await connection.queryAsync(sql, [id]);
    console.log(result);


    connection.end();
}
module.exports = { remove };