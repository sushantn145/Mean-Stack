const PI = 3.14;

module.exports = PI;