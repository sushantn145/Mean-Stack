const AREA = 100;
const PI = 3.14;
const APP_NAME = "NODE mod 4";

//console.log("I AM SMART JSON mod 4")

module.exports = {
    AREA,
    PI,
    APP_NAME,
}