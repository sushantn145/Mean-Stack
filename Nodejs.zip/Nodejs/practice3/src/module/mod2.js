const AREA = 20;
const PI = 3.14597;
const APP_NAME = "NODEJS mod2";

///console.log("I AM MOD2");

module.exports.AREA = AREA;
module.exports.PI = PI;
module.exports.APP_NAME = APP_NAME;
