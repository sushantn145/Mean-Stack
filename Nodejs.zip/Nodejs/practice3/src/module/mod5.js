const AREA = 200;
const PI = 3.14;
const APP_NAME = "NODE JS MOD5";

module.exports = {
    AREA: AREA,
    PI: PI,
    Name: APP_NAME,
}