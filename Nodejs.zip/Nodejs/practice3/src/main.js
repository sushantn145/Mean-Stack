const mod1 = require('./module/mod1')
const mod2 = require('./module/mod2')
const mod4 = require('./module/mod4')
const mod5 = require('./module/mod5');

console.log('Hello Welcome');

//Calling MOD1
console.log(mod1);
//calling MOD2
console.log(mod2.APP_NAME);
console.log(mod2.AREA);
console.log(mod2.PI);


/**calling MOD3
const total = mod3.additon(3, 5);
console.log(mod3.add);
console.log(mod3.sub);
console.log(mod3.mul);
console.log(mod3.div);
**/
//calling MOD4
console.log(mod4.AREA);
console.log(mod4.PI);
console.log(mod4.APP_NAME);

//calling MOD5
console.log(mod5.AREA);
console.log(mod5.PI);
console.log(mod5.APP_NAME);//output undifined bcoz here we used value not key form JSON

