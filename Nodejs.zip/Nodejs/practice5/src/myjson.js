const myjson = [
    { id: 1, city: "mumbai", temp: 33.25, Humadity: 80 },
    { id: 2, city: "pune", temp: 25.25, Humadity: 80 },
    { id: 3, city: "Nagpur", temp: 40.25, Humadity: 90 },
    { id: 4, city: "Delhi", temp: 28, Humadity: 75 },
];

module.exports = { myjson };

