const fs = require('fs');
const Promise = require('bluebird');

//promisification fo fs module
Promise.promisifyAll(fs);

let readdemo = () => {
    const filepath = "G:/Sushant/AWP/links.txt";
    fs.readFileAsync(filepath, { encoding: "utf-8" })
        .then((data) => {
            console.log(data);
        })
        .catch((data) => {
            console.log(err);
        });
};

readdemo();