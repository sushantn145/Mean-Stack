const fs = require('fs');
const Promise = require('bluebird');

//promification:convert all the callback methods and return as promise
Promise.promisifyAll(fs);

let readdemo = () => {
    const filepath = "G:/Sushant/AWP/links.txt";
    const mpromise = fs.readFileAsync(filepath, { encoding: "utf-8" });
    console.log(mpromise);
    //for SUCCESS
    mpromise
        .then((data) => {
            console.log(data);
        })
    //for failure
    mpromise.catch((err) => {
        console.log(err);
    })

};

readdemo();