const fs = require('fs');

let readfiledemo = () => {
    const filepath1 = "G:/Sushant/AWP/links.txt";
    fs.readFile(filepath1, { encoding: "utf-8" }, (err, data) => {
        console.log("1", data);

        //readfile 2
        const filepath2 = "G:/Sushant/AWP/links1.txt";
        fs.readFile(filepath2, { encoding: "utf-8" }, (err, data) => {
            console.log("2", data);

            //readfile 3
            const filepath3 = "G:/Sushant/AWP/links2.txt";
            fs.readFile(filepath3, { encoding: "utf-8" }, (err, data) => {
                console.log("3", data);

                //readfile 4
                const filepath4 = "G:/Sushant/AWP/links4.txt";
                fs.readFile(filepath4, { encoding: "utf-8" }, (err, data) => {
                    console.log("4", data);
                });
            });
        });
    });
};

readfiledemo();