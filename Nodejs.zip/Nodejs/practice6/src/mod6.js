const fs = require('fs');
const Promise = require('bluebird');

//priomosification of fs module
Promise.promisifyAll(fs);


let readdemo = () => {
    const filepath = "G:/Sushant/AWP/links.txt";
    const mpromise = fs.readFileAsync(filepath, { encoding: "utf-8" })

    mpromise
        .then((data) => {
            console.log(data);
        })
        .catch((data) => {
            console.log(data);
        });
};

readdemo();