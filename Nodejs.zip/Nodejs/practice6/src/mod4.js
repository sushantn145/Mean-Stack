const fs = require('fs');
const Promise = require('bluebird');


//promisification of fs module
Promise.promisifyAll(fs);

let readdemo = () => {
    const filepath = "G:/Sushant/AWP/links.txt";
    fs.readFileAsync(filepath, { encoding: "utf-8" })
        .then((data) => {
            //file 1 done
            console.log(data);

            const filepath1 = "G:/Sushant/AWP/links1.txt";
            return fs.readFileAsync(filepath1, { encoding: "utf-8" });
        })
        .then((data) => {
            //read file 2
            console.log(data)

            const filepath2 = "G:/Sushant/AWP/links.txt";
            return fs.readFileAsync(filepath2, { encoding: "utf-8" });
        })
        .then((data) => {
            //read file3
            console.log(data);
        })
}

readdemo();