const fs = require('fs');

let readdemo = () => {
    const filepath = "G:/Sushant/AWP/links.txt";
    fs.readFile(filepath, { encoding: "utf-8" }, (err, data) => {
        console.log(data);
    });
};

let readdemo1 = () => {
    try {
        const filepath1 = "G:/Sushant/AWP/links111.txt";
        const filecntent = fs.readFile(filepath1, { encoding: "utf-8" }, (err, data) => {
            console.log(err);
            console.log(data);
        })
    } catch (err) {
        console.log(err);
    }
}
module.exports = { readdemo, readdemo1 }