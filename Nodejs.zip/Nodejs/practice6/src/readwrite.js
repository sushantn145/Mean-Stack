const fs = require('fs');
let readfile = () => {
    console.log("readfile will be done here");

};

let writefile = () => {
    console.log("write file will be done here")
};

module.exports = { readfile, writefile }
//code with harry