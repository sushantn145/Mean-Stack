const fs = require('fs');
const Promise = require('bluebird');

//promisification for fs module
Promise.promisifyAll(fs);

let readdemo = async () => {
    try {
        const filepath = "G:/Sushant/AWP/links.txt";
        const data1 = await fs.readFileAsync(filepath, { encoding: "utf-8" });
        console.log(data1);

        const filepath1 = "G:/Sushant/AWP/size.txt";
        const data2 = await fs.readFileAsync(filepathe1, { encoding: "utf-8" });
        console.log(data2);

        const filepath2 = "G:/Sushant/AWP/tablecv.txt";
        const data3 = await fs.readFileAsync(filepath2, { encoding: "utf-8" });
        console.log('data3');
    }
    catch (err) {
        console.log(err.message, ":one catch for all Code")
    }


};

readdemo();