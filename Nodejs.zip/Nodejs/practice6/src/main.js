console.log('Hello')
//const filemod = require('./readwrite');
//filemod.readfile();
//filemod.writefile();

//const filemod = require('./mod1');
const filemod2 = require('./mod2');
//filemod.readdemo1();
filemod2.readfiledemo();