const fs = require('fs');


let readfiledemo = () => {
    //Read file 1
    const filepath = "G:/Sushant/AWP/links.txt";
    fs.readFile(filepath, { encoding: "utf-8" }, (err, data) => {
        console.log("1", data);
    });

    //Read file 2
    const filepath1 = "G:/Sushant/AWP/tablecv.txt";
    fs.readFile(filepath1, { encoding: "utf-8" }, (err, data) => {
        console.log("2", data);
    });

    //Read file 3
    const filepath2 = "G:/Sushant/AWP/size.txt";
    fs.readFile(filepath2, { encoding: "utf-8" }, (err, data) => {
        console.log("3", data);
    });
};
module.exports = { readfiledemo }