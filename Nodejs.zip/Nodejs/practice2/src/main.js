
//Importing the module
let Person = require('./person')
let Employee = require('./employee')

class Main {
    static main() {
        console.log('This is the execution point');

        let p = new Person();
        let poutput = p.getName();

        let e = new Employee();
        let empoutput = e.emp();


        console.log(poutput);
        console.log(empoutput);
    }

}
Main.main();