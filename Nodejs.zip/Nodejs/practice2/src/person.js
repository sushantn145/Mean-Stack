class Person {
    constructor() {
        console.log('I AM constructo');
    }
    getName() {
        return "I am NodeJS ";
    }
}
//exporting the class as module 
module.exports = Person;