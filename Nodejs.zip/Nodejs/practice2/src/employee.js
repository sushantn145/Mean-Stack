class Employee {

    emp() {
        return "I am Employee";
    }
}

module.exports = Employee;