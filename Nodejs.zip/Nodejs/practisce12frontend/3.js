// var x = new Boolean(false);
// var y = new Boolean(false);
// console.log((x == y),(x === y));


//console.log((x === y));

// console.log(true == []); // -> false
// console.log(true == ![]); // -> false

console.log([1, 2, 3] + [4, 5, 6]);

// var arr = [1, 2, 3]
// var arr1 = [4, 5, 6];
// var result = arr + arr1;
// console.log(result);
