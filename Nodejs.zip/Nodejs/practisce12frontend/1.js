let registerhere = () => {
    const id = $('#parent').children[0].children[0].value;
    const sname = $('#parent').children[1].children[0].value;
    const address = $('#parent').children[2].children[0].value;
    const mobno = $('#parent').children[3].children[0].value;

    //http://localhost/adduser?id=25&sname=sushant&address=Pune&mobno=93939;
    let url = "http://localhost/adduser?";

    url += "id=" + id + "&";
    url += "sname" + sname + "&";
    url += "address" + address + "&";
    url += "mobno" + mobno + "&";

    const xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.onload = () => {
        const res = xhr.responseText;
        console.log(res);


        $('#parent').children[0].children[0].value = "";
        $('#parent').children[1].children[0].value = "";
        $('#parent').children[2].children[0].value = "";
        $('#parent').children[3].children[0].value = "";
    }

    xhr.send();
}