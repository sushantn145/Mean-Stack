let registerhereget = async () => {
    const id = document.querySelector('#parent').children[0].children[0].value;
    const sname = document.querySelector('#parent').children[1].children[0].value;
    const address = document.querySelector('#parent').children[2].children[0].value;
    const mobno = document.querySelector('#parent').children[3].children[0].value;

    //http://localhost/adduser?id=25&sname=sushant&address=Pune&mobno=93939;
    //let url = "http://localhost:3000/adduser?";
    // url += "id=" + id + "&";
    // url += "sname=" + sname + "&";
    // url += "address=" + address + "&";
    // url += "mobno=" + mobno;

    let url = `http://localhost:3000/adduser?id=${id}&sname=${sname}&address=${address}&mobno=${mobno}`;
    // const xhr = new XMLHttpRequest();
    // xhr.open("GET", url);
    // xhr.onload = () => {
    //     const res = xhr.responseText;
    //     console.log(res);
    // }
    // xhr.send();

    //ajax call
    await fetch(url);

    document.querySelector('#parent').children[0].children[0].value = "";
    document.querySelector('#parent').children[1].children[0].value = "";
    document.querySelector('#parent').children[2].children[0].value = "";
    document.querySelector('#parent').children[3].children[0].value = "";
};



let registerherepost = async () => {
    const id = document.querySelector('#parent').children[0].children[0].value;
    const sname = document.querySelector('#parent').children[1].children[0].value;
    const address = document.querySelector('#parent').children[2].children[0].value;
    const mobno = document.querySelector('#parent').children[3].children[0].value;

    const input = {
        id,
        sname,
        address,
        mobno,
    };
    console.log(input);
    let url1 = "http://localhost:3000/adduser";
    //http understand text
    await fetch(url1, {
        method: "POST",
        body: JSON.stringify(input),
        headers: {
            "Content-Type": "application/json",
        },

    });


    //  const data = { uname, pass, email, contact, dob, sel };

    // await fetch(url, {
    //     method: "POST",
    //     headers: {
    //         "Content-Type": 'application/json',
    //     },
    //     body: JSON.stringify(data),
    // });
    //
    document.querySelector('#parent').children[0].children[0].value = "";
    document.querySelector('#parent').children[1].children[0].value = "";
    document.querySelector('#parent').children[2].children[0].value = "";
    document.querySelector('#parent').children[3].children[0].value = "";

};