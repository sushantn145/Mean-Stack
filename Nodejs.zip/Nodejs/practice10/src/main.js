const express = require('express');
const app = express();

//http://localhost:3000/  URL::API:Rest API
//http://localhost:3000/?id=2&name=Tushar Khaire
app.get("/", (req, res) => {
    const json = {
        id: 1, name: "Sushant Nikalje"
    }
    res.json(json);
});


//http://localhost:3000/search
app.get("/search", (req, res) => {

    const json = { id: 2, name: "Tushar Khaire" }
    res.json(json)
});


app.listen(4000);