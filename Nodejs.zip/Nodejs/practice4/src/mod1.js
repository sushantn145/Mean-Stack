
let add = (n1, n2) => {
    return n1 + n2;
}

let sub = function (n1, n2) {
    return n1 - n2;
}

function div(n1, n2) {
    return n1 / n2;
}

let mul = (n1, n2) => {
    return n1 * n2;
}

module.exports = {
    additon: add,
    subtraction: sub,
    multiplication: mul,
    division: div,
};