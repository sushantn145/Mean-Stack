const cal = require('./mod1');
const my_num = require('./mod2');
/**const str = require('./mod2');
const bool = require('./mod2');
const arr1 = require('./mod2');
const arrstr = require('./mod2');
const myjson = require('./mod2');
const myjsonarr = require('./mod2');
*/
console.log("Hello")

const total1 = cal.additon(5, 3);
console.log("Addition:", total1);
const total2 = cal.subtraction(5, 3);
console.log("Subtraction:", total2);
const total3 = cal.multiplication(5, 3);
console.log("Multiplication:", total3);
const total4 = cal.division(9, 3);
console.log("Division:", total4)

console.log(my_num.my_num);
console.log(my_num.str);
console.log(my_num.bool);
console.log(my_num.arr1);
console.log(my_num.arrstr);
console.log(my_num.myjson);
console.log(my_num.myjsonarr);