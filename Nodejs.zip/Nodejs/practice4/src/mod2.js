const my_num = 253.65;
const str = "This is String";
const bool = true;

const arr1 = [1, 2, 3, 4, 5];
const arrstr = ["Sushant", "Tushar", "Amol", "Manoj"];

const myjson =
    { id1: 1, title: "JSON" };

const myjsonarr = [
    { id: 1, title: "AJAX" },
    { id: 2, title: "XML" },
    { id: 3, title: "Angular" },
];

module.exports = {
    my_num,
    str,
    bool,
    arr1,
    arrstr,
    myjson,
    myjsonarr,
}